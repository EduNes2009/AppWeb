package ar.org.centro8.curso.especialidad.aplicaciones.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JspApplication {

	public static void main(String[] args) {
		SpringApplication.run(JspApplication.class, args);
	}

}
